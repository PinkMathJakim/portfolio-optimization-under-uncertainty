import numpy as np, pandas as pd
from src.backtest import rolling_backtest
def test_backtest_starts_after_training_and_has_no_future_dates():
 idx=pd.bdate_range('2018-01-01',periods=300); r=pd.DataFrame(np.random.default_rng(1).normal(.0002,.01,(300,4)),index=idx,columns=list('ABCD'))
 out,weights=rolling_backtest(r,'equal_weight',train_window=100,rebalance_every=20,max_weight=.5,transaction_cost_bps=5)
 assert out.index.min()>idx[99] and len(out)>0 and len(weights)>0
 assert all(abs(sum(x.values())-1)<1e-6 for x in weights['weights'])
